package this_team;

import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.geometry.Box;

public abstract class ObjectManager {
    protected TransformGroup objTG = new TransformGroup();
    protected Box backgroundBox;
    
    public TransformGroup position_Object() {
        return objTG;
    }
    
}