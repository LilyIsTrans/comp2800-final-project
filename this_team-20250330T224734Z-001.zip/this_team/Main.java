package this_team;

import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.universe.SimpleUniverse;
import org.jogamp.java3d.utils.universe.ViewingPlatform;
import org.jogamp.vecmath.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JPanel implements KeyListener {
  private static final long serialVersionUID = 1L;
  private static JFrame frame;
  private LudoBoard ludoBoard;
  private Grid grid;
  private GameLogic gameLogic;
  private int selectedPieceIndex = 0;
  private JLabel positionLabel;
  private Canvas3D canvas;

  public static void main(String[] args) {
    frame = new JFrame("Ludo Game");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().add(new Main());
    frame.setSize(800, 800);
    frame.setVisible(true);
  }

  public Main() {
    GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
    canvas = new Canvas3D(config);
    canvas.setFocusable(true);
    canvas.requestFocusInWindow();
    canvas.addKeyListener(this);

    BranchGroup scene = createScene();
    SimpleUniverse su = new SimpleUniverse(canvas);
    setupTopDownCamera(su);
    scene.compile();
    su.addBranchGraph(scene);

    setLayout(new BorderLayout());
    add(canvas, BorderLayout.CENTER);

    positionLabel = new JLabel("Begin game - press SPACE to roll");
    add(positionLabel, BorderLayout.SOUTH);
  }

  private BranchGroup createScene() {
    BranchGroup scene = new BranchGroup();
    TransformGroup sceneTG = new TransformGroup();

    // 1. Ludo Board
    ludoBoard = new LudoBoard();
    sceneTG.addChild(ludoBoard.position_Object()); // Z = -0.51

    // 2. Grid
    grid = new Grid();
    sceneTG.addChild(grid.position_Object()); // Z = 0.01

    // 3. Initialize teams and add to scene
    Team[] teams = {
      new RedTeam(grid.getSize(), grid.getCellSize()),
      new YellowTeam(grid.getSize(), grid.getCellSize())
    };
    gameLogic = new GameLogic(teams);

    // Add all teams' TransformGroups
    for (Team team : teams) {
      sceneTG.addChild(team.getTransformGroup()); // Z = 0.1
    }

    // 4. Lighting
    AmbientLight ambient = new AmbientLight(new Color3f(1f, 1f, 1f));
    ambient.setInfluencingBounds(new BoundingSphere(new Point3d(0, 0, 0), 100));
    sceneTG.addChild(ambient);

    scene.addChild(sceneTG);
    return scene;
  }

  @Override
  public void keyPressed(KeyEvent e) {
    // Handle piece selection (1-4 keys)
    if (e.getKeyCode() >= KeyEvent.VK_1 && e.getKeyCode() <= KeyEvent.VK_4) {
      selectedPieceIndex = e.getKeyCode() - KeyEvent.VK_1;
      positionLabel.setText(
        gameLogic.getCurrentTeam().getTeamName() +
        " piece " + (selectedPieceIndex + 1) + " selected"
      );
      return;
    }

    switch (e.getKeyCode()) {
      case KeyEvent.VK_SPACE:
        if (gameLogic.isWaitingForRoll()) {
          gameLogic.rollDice();
          gameLogic.handleTurn();
          if (gameLogic.isNoMovesState()) {
            positionLabel.setText(
              gameLogic.getCurrentTeam().getTeamName() +
              " rolled " + gameLogic.getCurrentDiceValue() +
              " - NO POSSIBLE MOVES (Press ENTER)"
            );
          } else {
            positionLabel.setText(
              gameLogic.getCurrentTeam().getTeamName() +
              " rolled " + gameLogic.getCurrentDiceValue() +
              (gameLogic.isWaitingForMove() ? " - select piece (1-4)" : "")
            );
          }
        }
        break;

      case KeyEvent.VK_ENTER:
        if (gameLogic.isWaitingForMove()) {
          gameLogic.moveSelectedPiece(selectedPieceIndex);
          positionLabel.setText(
            gameLogic.getCurrentTeam().getTeamName() +
            (gameLogic.isWaitingForRoll() ? "'s turn - press SPACE" : " - select piece (1-4)")
          );
        }
        else if (gameLogic.isNoMovesState()) {
          gameLogic.forceTurnEnd(); // New method to advance turn
          positionLabel.setText(
            gameLogic.getCurrentTeam().getTeamName() +
            "'s turn - press SPACE"
          );
        }
        break;

      case KeyEvent.VK_G:
        grid.toggleVisibility();
        break;

      case KeyEvent.VK_B:
        ludoBoard.toggleVisibility();
        break;
    }
  }

  @Override
  public void keyReleased(KeyEvent e) {}

  @Override
  public void keyTyped(KeyEvent e) {}

  private void setupTopDownCamera(SimpleUniverse su) {
    ViewingPlatform vp = su.getViewingPlatform();
    TransformGroup cameraTG = vp.getViewPlatformTransform();

    Transform3D viewTransform = new Transform3D();
    viewTransform.lookAt(
      new Point3d(0, 0, 15),
      new Point3d(0, 0, 0),
      new Vector3d(0, 1, 0)
    );
    viewTransform.invert();
    cameraTG.setTransform(viewTransform);
  }
}