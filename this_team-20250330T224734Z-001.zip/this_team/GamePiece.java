package this_team;

import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.geometry.Sphere;
import org.jogamp.vecmath.*;

public class GamePiece {
    private TransformGroup pieceTG;
    private Transform3D transform;

    public GamePiece(float cellSize, Color3f clr) {

        // Use MaterialManager to create an Appearance with the red material.
        Appearance pieceApp = MaterialManager.set_Appearance(clr);
        
        // Create a sphere to represent the game piece.
        Sphere pieceSphere = new Sphere(cellSize / 3, Sphere.GENERATE_NORMALS | Sphere.ENABLE_PICK_REPORTING, 100, pieceApp);
        
        // Set up the TransformGroup for moving the piece.
        pieceTG = new TransformGroup();
        pieceTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        pieceTG.addChild(pieceSphere);
        
        transform = new Transform3D();
    }
    
    public TransformGroup getTransformGroup() {
        return pieceTG;
    }
    
    public void moveTo(float x, float y, float z) {
        Vector3f pos = new Vector3f(x, y, z);
        transform.setTranslation(pos);
        pieceTG.setTransform(transform);
        System.out.println("GamePiece moved to: (" + x + ", " + y + ", " + z + ")");
    }
}