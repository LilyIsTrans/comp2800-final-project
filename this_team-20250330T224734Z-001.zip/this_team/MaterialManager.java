package this_team;

import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;

public class MaterialManager {
    
	public final static Color3f White = new Color3f(1.0f, 1.0f, 1.0f);
	public final static Color3f Red = new Color3f(1.0f, 0.0f, 0.0f);
	public final static Color3f Orange = new Color3f(1.0f, 0.6f, 0.0f);
	public final static Color3f Yellow = new Color3f(1.0f, 1.0f, 0.0f);
	public final static Color3f Green = new Color3f(0.0f, 1.0f, 0.0f);
	public final static Color3f Blue = new Color3f(0.0f, 0.0f, 1.0f);
	public final static Color3f Cyan = new Color3f(0.0f, 1.0f, 1.0f);
	public final static Color3f Magenta = new Color3f(1.0f, 0.0f, 1.0f);
	public final static Color3f Purple = new Color3f(0.5f, 0.0f, 0.5f);
	public final static Color3f Grey = new Color3f(0.35f, 0.35f, 0.35f);
	public final static Color3f Black = new Color3f(0.0f, 0.0f, 0.0f);
	public final static Color3f Lime = new Color3f(0.0f, 1.0f, 0.5f);
	public static Color3f[] list_clrs = {White, Red, Orange, Yellow, Green, Blue, Purple, Black};


    public static Material set_Material(Color3f m_clr) {
        Material mtl = new Material();
        mtl.setShininess(32);
        mtl.setAmbientColor(m_clr);    // Use the input color for ambient
        mtl.setDiffuseColor(m_clr);    // Use the input color for diffuse
        mtl.setSpecularColor(Grey);    // Specular can remain as Grey (or adjust if needed)
        mtl.setEmissiveColor(m_clr);   // Use the input color for emissive
        mtl.setLightingEnable(true);
        return mtl;
    }
    
    /**
     * Creates and returns an Appearance using the Material created from the given color.
     */
    public static Appearance set_Appearance(Color3f clr) {		
        Appearance app = new Appearance();
        app.setMaterial(set_Material(clr));
        return app;
    }
}